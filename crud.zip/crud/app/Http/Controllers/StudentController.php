<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;


use App\Models\student;

class StudentController extends Controller
{
    //

    public function show(){

        $students = student::all();

        return view('welcome',['student'=>$students]);


    }
    public function edit($id){

     $data= student::find($id);

     return view('edit',['data'=>$data]);


    }


    public function update(Request $request, $id)
{
    $request->validate([
        'name' => 'required',
        'city' => 'required',
    ]);

    $user = Student::find($id);
    $user->name = $request->input('name');
    $user->city = $request->input('city');

    $user->update();


    return redirect('/')->with('success', 'Item updated successfully');

}
public function insert(request $req){
    $req->validate([
        'name' => 'required',
        'city' => 'required',
        ]);
        $student = new student();
        $student->name = $req->input('name');
        $student->city = $req->input('city');
        $student->save();
        return redirect('/')->with('success', 'Item created successfully');



}
public function delete($id){

    $student = Student:: find($id);
    $student->delete();


    return redirect('/')->with('success', 'Item deleted successfully');




}
}
