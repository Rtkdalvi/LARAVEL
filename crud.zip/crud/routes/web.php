<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;

Route::get('/',[StudentController::class,'show']);
Route::get('/edit/{id}',[StudentController::class,'edit']);
Route::put('update/{id}',[StudentController::class,'update']);
Route::get('add/',function()
{

    return view('insert');


}
);

route::put('insert/',[StudentController::class,'insert']);
Route::get('delete/{id}',[Studentcontroller::class,'delete']);

