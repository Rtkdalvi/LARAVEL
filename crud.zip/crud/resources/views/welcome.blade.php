<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-table@1.23.2/dist/themes/bootstrap-table/bootstrap-table.min.css">

    <title>Hello, Bootstrap Table!</title>
  </head>
  <body>
    <h2><a href="{{url('/add')}}">ADD record</a></h2>

    <table data-toggle="table">
      <thead>

        <tr>
          <th> ID</th>
          <th> Name</th>
          <th> City</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        @php
            $i=0;
        @endphp
@foreach ($student as  $std)

<tr>
    <td>{{++$i}}</td>
    <td>{{$std->name}}</td>
    <td>{{$std->city}}</td>
    <td><a href="{{url('edit/'.$std->id)}}">Edit</a></td>
    <td><a href="{{url('delete/'.$std->id)}}">DELETE</a></td>

  </tr>

@endforeach


      </tbody>
    </table>

    <script src="https://cdn.jsdelivr.net/npm/jquery/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-table@1.23.2/dist/bootstrap-table.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-table@1.23.2/dist/themes/bootstrap-table/bootstrap-table.min.js"></script>
  </body>
</html>
