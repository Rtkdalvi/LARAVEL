<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-table@1.23.2/dist/themes/bootstrap-table/bootstrap-table.min.css">

    <title>Hello, Bootstrap Table!</title>
  </head>
  <body>
    <h2><a href="<?php echo e(url('/add')); ?>">ADD record</a></h2>

    <table data-toggle="table">
      <thead>

        <tr>
          <th> ID</th>
          <th> Name</th>
          <th> City</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
            $i=0;
        ?>
<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
    <td><?php echo e(++$i); ?></td>
    <td><?php echo e($std->name); ?></td>
    <td><?php echo e($std->city); ?></td>
    <td><a href="<?php echo e(url('edit/'.$std->id)); ?>">Edit</a></td>
    <td><a href="<?php echo e(url('delete/'.$std->id)); ?>">DELETE</a></td>

  </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </tbody>
    </table>

    <script src="https://cdn.jsdelivr.net/npm/jquery/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-table@1.23.2/dist/bootstrap-table.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-table@1.23.2/dist/themes/bootstrap-table/bootstrap-table.min.js"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\crud\resources\views/welcome.blade.php ENDPATH**/ ?>