<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class rtk extends Controller
{

    function show($id,$name){
       

           
        if($id==12 AND $name=='rutik'){
        
           
        
            return view('users',['key'=>$id],['name'=>$name]);
        }
        else{
        
           return 'NO ENTER';
        }
        
        
            }

            function data(){

                return view('data');


            }

    
    //
}
