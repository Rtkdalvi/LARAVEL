<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>users page</title>
</head>
<body>
    <h1>Data Information</h1><hr>

<?php echo e($key); ?>

<hr>
<?php echo e($name); ?>

<hr>
<a href="/">rutik</a>
    
    
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\pro1\resources\views/users.blade.php ENDPATH**/ ?>