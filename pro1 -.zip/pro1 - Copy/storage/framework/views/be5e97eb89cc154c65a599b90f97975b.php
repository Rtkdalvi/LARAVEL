<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page laravel

    </title>
</head>
<body>

<h1>welcome To Home Page
</h1> 
GOTO => <a href="/users">Show Information</a>   
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\pro1\resources\views/welcome.blade.php ENDPATH**/ ?>