<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\rtk;


Route::get('/', function () {
    return view('welcome');
});


Route::get('users/{id}/{name}',[rtk::class,'show'])->WhereNumber('id')->WhereAlpha('name');

Route :: get('/about',[rtk::class,'data']);




